# Main Controller Project

Heltec LoRa + EC200U based irrigation controller.